#include <jni.h>
#include <string>
#include "xbox_iso_parser.h"

#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jboolean JNICALL
Java_com_termux_app_XoDosFileManager_loadISO(JNIEnv *env, jobject thiz, jstring iso_path);

JNIEXPORT jboolean JNICALL
Java_com_termux_app_XoDosFileManager_extractFile(JNIEnv *env, jobject thiz, 
                                                jstring iso_path, jstring file_path, 
                                                jstring output_path);

JNIEXPORT jboolean JNICALL
Java_com_termux_app_XoDosFileManager_extractAllFiles(JNIEnv *env, jobject thiz,
                                                   jstring iso_path, jstring output_dir);

JNIEXPORT jobjectArray JNICALL
Java_com_termux_app_XoDosFileManager_listFiles(JNIEnv *env, jobject thiz, jstring iso_path);

JNIEXPORT jbyteArray JNICALL
Java_com_termux_app_XoDosFileManager_readXBE(JNIEnv *env, jobject thiz, jstring iso_path);

JNIEXPORT jboolean JNICALL
Java_com_termux_app_XoDosFileManager_convertForXemu(JNIEnv *env, jobject thiz,
                                                   jstring iso_path, jstring output_dir);

#ifdef __cplusplus
}
#endif